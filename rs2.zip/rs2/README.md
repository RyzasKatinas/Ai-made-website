# RandomScroll (Netlify + Netlify Blobs)
Accounts, likes, saves, follows, comments and view counts are stored in Netlify Blobs. No database needed.

## Deploy
1. Push this folder to a GitHub repo.
2. Netlify > Add new site > Import from Git > pick the repo (no build command; publish dir `public`).
3. Site configuration > Environment variables:
   - JWT_SECRET (required): any long random string
   - YOUTUBE_API_KEY (optional): Google Cloud Console > enable "YouTube Data API v3" > Credentials > Create API key
4. Deploy. Drag-and-drop deploys do NOT include functions; use Git or `netlify deploy --prod`.

Local: `npx netlify dev` (needs the env vars in a `.env` file).
