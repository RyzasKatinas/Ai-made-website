import crypto from 'node:crypto';
import {getStore} from '@netlify/blobs';

const YT=process.env.YOUTUBE_API_KEY,SECRET=process.env.JWT_SECRET;
const S=n=>getStore({name:n,consistency:'strong'});
const h=s=>crypto.createHash('sha1').update(s).digest('hex').slice(0,24);
class E extends Error{constructor(m,c=400){super(m);this.c=c}}
const j=(o,c=200)=>new Response(JSON.stringify(o),{status:c,headers:{'content-type':'application/json','cache-control':'no-store'}});
const enc=encodeURIComponent,rnd=n=>Math.floor(Math.random()*n),pick=a=>a[rnd(a.length)];
const shuffle=a=>a.map(x=>[Math.random(),x]).sort((p,q)=>p[0]-q[0]).map(x=>x[1]);
const STRONG=/\b(fuck|shit|bitch|cunt|nazi|kill yourself)\b/i,MILD=/\b(damn|hell|crap|stupid|idiot)\b/gi; // starter lists: use a real moderation service in production
const BAD=/\b(nude|naked|porn|sex|sexy|erotic|nsfw|gore|fetish|xxx)\b/i;
const LANGS=['en-US','es-ES','fr-FR','de-DE','pt-BR','ja-JP'];
const TOPICS={comedy:['funny','comedy sketch'],gaming:['gameplay','video game'],science:['science experiment','physics'],technology:['technology','robot'],education:['educational','how it works'],entertainment:['music performance','dance'],nature:['wildlife','nature'],travel:['travel','city timelapse']};
const YTCAT={comedy:23,gaming:20,science:28,technology:28,education:27,entertainment:24,nature:15,travel:19};
const ID=/^(yt|commons|archive):[\w.\-]{1,200}$/;
const dec=s=>String(s).replace(/&(amp|lt|gt|quot|#39);/g,m=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#39;':"'"}[m]));
const J=async u=>{const r=await fetch(u,{headers:{'user-agent':'RandomScroll/2.0 (Netlify)'},signal:AbortSignal.timeout(6000)});if(!r.ok)throw new Error(new URL(u).hostname+' '+r.status);return r.json()};

/* ---- auth (HMAC tokens + scrypt, no dependencies) ---- */
const b64=b=>Buffer.from(b).toString('base64url');
const mac=s=>crypto.createHmac('sha256',SECRET).update(s).digest('base64url');
const sign=uid=>{const p=b64(JSON.stringify({uid,exp:Date.now()+30*864e5}));return p+'.'+mac(p)};
const verify=t=>{try{if(!SECRET||!t)return null;const[p,m]=t.split('.');const a=Buffer.from(m),b=Buffer.from(mac(p));if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;const d=JSON.parse(Buffer.from(p,'base64url'));return d.exp>Date.now()?d.uid:null}catch{return null}};
const hashpw=(pw,salt)=>crypto.scryptSync(pw,salt,32).toString('hex');
const getUser=uid=>uid?S('users').get('u/'+uid,{type:'json'}):null;
const needUser=async uid=>{const u=await getUser(uid);if(!u)throw new E('Log in to do that',401);return u};
const putUser=u=>S('users').setJSON('u/'+u.id,u);
const pub=u=>({id:u.id,display_name:u.display_name,prefs:u.prefs});
async function limit(kind,ip,max,secs){const s=S('ratelimit'),k=`${kind}/${ip}/${Math.floor(Date.now()/1e3/secs)}`;const n=(await s.get(k,{type:'json'}))||0;if(n>=max)throw new E('Too many requests, slow down',429);await s.setJSON(k,n+1)}

/* ---- video helpers ---- */
const okHost=u=>{try{const x=new URL(u);return x.protocol==='https:'&&/(^|\.)(archive\.org|wikimedia\.org|ytimg\.com|youtube\.com)$/.test(x.hostname)}catch{return false}};
const cleanVideo=o=>{const s=(k,n=200)=>String(o?.[k]??'').slice(0,n);
  const v={id:s('id'),kind:s('kind',4),src:s('src',500),title:s('title'),creator:s('creator',100),cid:s('cid',100),source:s('source',20),page:s('page',500),poster:s('poster',500)};
  if(!ID.test(v.id)||!['yt','file'].includes(v.kind)||!['youtube','commons','archive'].includes(v.source)||!okHost(v.page)||(v.poster&&!okHost(v.poster))||(v.kind==='yt'?!/^[\w-]{11}$/.test(v.src):!okHost(v.src)))throw new E('Invalid video');
  return v};
const bump=async(id,fn)=>{const s=S('videos'),k='v/'+h(id);const d=(await s.get(k,{type:'json'}))||{likes:0,views:0,comments:0,reports:0};fn(d);await s.setJSON(k,d);return d};
const statsFor=async ids=>Object.fromEntries(await Promise.all(ids.map(async id=>[id,(await S('videos').get('v/'+h(id),{type:'json'}))||{likes:0,views:0,comments:0}])));
const decorate=(v,st,u)=>({...v,likes:st.likes,views:st.views,comments:st.comments,liked:!!u?.likes.includes(v.id),saved:!!u?.saves.some(x=>x.id===v.id),following:!!u?.follows.some(f=>f.source===v.source&&f.cid===v.cid)});
const vidId=b=>{if(!ID.test(String(b.id)))throw new E('Invalid video id');return b.id};

/* ---- sources ---- */
async function commons({q,user}={}){
  const base='https://commons.wikimedia.org/w/api.php?action=query&format=json&prop=videoinfo&viiprop=url|user|mime|size|derivatives&viiurlwidth=480';
  const sel=user?`&generator=allimages&gaiuser=${enc(user)}&gaimime=video/webm&gailimit=20`:`&generator=search&gsrnamespace=6&gsrlimit=20&gsroffset=${rnd(60)}&gsrsearch=${enc('filetype:video '+q+' -nude -sex -porn -erotic')}`;
  const d=await J(base+sel);
  return Object.values(d.query?.pages||{}).map(p=>{
    const i=p.videoinfo?.[0];if(!i)return null;const D=i.derivatives||[];
    const dv=D.find(x=>x.transcodekey==='480p.mp4')||D.find(x=>x.transcodekey==='360p.mp4')||D.find(x=>/\.mp4$/.test(x.transcodekey||''))||D.find(x=>/webm/.test(x.type||''));
    const src=dv?.src||(/webm|ogg|mp4/.test(i.mime||'')&&i.size<60e6?i.url:null);if(!src)return null;
    return{id:'commons:'+p.pageid,kind:'file',src,title:p.title.replace(/^File:/,'').replace(/\.\w+$/,'').replace(/[_-]+/g,' '),creator:i.user||'Wikimedia',cid:i.user||'Wikimedia',source:'commons',page:i.descriptionurl,poster:i.thumburl||''}}).filter(Boolean);
}
async function archive({q,creator,sort}={}){
  const qq=creator?`creator:"${creator.replace(/["\\]/g,'')}" AND mediatype:movies`:`${q?`(${q}) AND `:''}mediatype:movies AND licenseurl:(*creativecommons* OR *publicdomain*) AND NOT subject:(adult OR nsfw OR erotic)`;
  const d=await J(`https://archive.org/advancedsearch.php?q=${enc(qq)}&fl[]=identifier&fl[]=title&fl[]=creator&rows=12&page=${1+rnd(sort?4:8)}&output=json${sort?'&sort[]=downloads+desc':''}`);
  const out=await Promise.all((d.response?.docs||[]).slice(0,8).map(async x=>{try{
    const m=await J('https://archive.org/metadata/'+enc(x.identifier));
    const f=(m.files||[]).find(f=>/\.mp4$/i.test(f.name)&&+f.size<80e6);if(!f)return null;
    const c=String([].concat(x.creator||'Internet Archive')[0]).slice(0,100);
    return{id:'archive:'+x.identifier,kind:'file',src:`https://archive.org/download/${enc(x.identifier)}/${f.name.split('/').map(enc).join('/')}`,title:String([].concat(x.title||x.identifier)[0]),creator:c,cid:c,source:'archive',page:'https://archive.org/details/'+enc(x.identifier),poster:'https://archive.org/services/img/'+enc(x.identifier)}}catch{return null}}));
  return out.filter(Boolean);
}
async function youtube({q,cat,channel,popular,lang}){
  let u;
  if(popular)u=`https://www.googleapis.com/youtube/v3/videos?part=snippet,status&chart=mostPopular&maxResults=30&regionCode=${lang.slice(3)}&key=${YT}`;
  else{const before=new Date(Date.now()-rnd(8*365)*864e5).toISOString();
    u=`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&videoSyndicated=true&videoDuration=short&safeSearch=strict&maxResults=15&relevanceLanguage=${lang.slice(0,2)}&publishedBefore=${before}&key=${YT}`+(channel?`&channelId=${enc(channel)}`:`&q=${enc(q)}`+(YTCAT[cat]?`&videoCategoryId=${YTCAT[cat]}`:''))}
  const d=await J(u);
  return(d.items||[]).filter(v=>!v.status||v.status.embeddable).map(v=>{const id=v.id.videoId||v.id;
    return{id:'yt:'+id,kind:'yt',src:id,title:dec(v.snippet.title),creator:dec(v.snippet.channelTitle),cid:v.snippet.channelId,source:'youtube',page:'https://www.youtube.com/watch?v='+id,poster:v.snippet.thumbnails?.high?.url||''}});
}

/* ---- routes ---- */
const R={
'POST /register':async({body,ip})=>{
  if(!SECRET)throw new E('Server is missing JWT_SECRET',500);await limit('auth',ip,20,3600);
  const{email,password}=body;
  if(typeof email!=='string'||!/^\S+@\S+\.\S+$/.test(email)||email.length>120||typeof password!=='string'||password.length<8||password.length>100)throw new E('Enter a valid email and a password of 8+ characters');
  const e=email.toLowerCase(),us=S('users');
  if(await us.get('e/'+e))throw new E('That email is already registered',409);
  let id;do{id='User_'+crypto.randomInt(100000,1000000)}while(await us.get('u/'+id));
  const salt=crypto.randomBytes(16).toString('hex');
  const u={id,email:e,salt,pass:hashpw(password,salt),display_name:id,prefs:{},likes:[],saves:[],follows:[],seen:[],ncomments:0,created:Date.now()};
  await us.setJSON('u/'+id,u);await us.setJSON('e/'+e,{id});
  return{token:sign(id),user:pub(u)}},
'POST /login':async({body,ip})=>{
  if(!SECRET)throw new E('Server is missing JWT_SECRET',500);await limit('auth',ip,20,3600);
  const l=String(body.login||'').trim(),us=S('users');
  const id=/^User_\d+$/.test(l)?l:(await us.get('e/'+l.toLowerCase(),{type:'json'}))?.id;
  const u=id&&await getUser(id);
  if(!u||typeof body.password!=='string'||!crypto.timingSafeEqual(Buffer.from(hashpw(body.password,u.salt)),Buffer.from(u.pass)))throw new E('Wrong ID/email or password',401);
  return{token:sign(u.id),user:pub(u)}},
'GET /me':async({uid})=>({user:pub(await needUser(uid))}),
'PUT /me':async({uid,body})=>{const u=await needUser(uid);
  if(body.display_name!==undefined){const n=String(body.display_name).trim().replace(/\s+/g,' ');if(!n||n.length>30||STRONG.test(n))throw new E('Display name must be 1–30 clean characters');u.display_name=n}
  if(body.prefs!==undefined){if(!body.prefs||typeof body.prefs!=='object'||Array.isArray(body.prefs)||JSON.stringify(body.prefs).length>2000)throw new E('Invalid preferences');u.prefs=body.prefs}
  await putUser(u);return{user:pub(u)}},
'DELETE /me':async({uid})=>{const u=await needUser(uid),C=S('comments');
  for(const{key}of(await C.list()).blobs){const d=await C.get(key,{type:'json'}),f=d.filter(c=>c.uid!==u.id);if(f.length!==d.length)await C.setJSON(key,f)}
  await S('users').delete('u/'+u.id);await S('users').delete('e/'+u.email);return{ok:true}},
'DELETE /history':async({uid})=>{const u=await needUser(uid);u.seen=[];await putUser(u);return{ok:true}},
'GET /profile':async({uid})=>{const u=await needUser(uid);return{likes:u.likes.length,saves:u.saves.length,comments:u.ncomments||0,following:u.follows}},

'GET /feed':async({url,uid})=>{
  const q=url.searchParams,mode=['random','trending','following'].includes(q.get('mode'))?q.get('mode'):'random';
  const lang=LANGS.includes(q.get('lang'))?q.get('lang'):'en-US',user=await getUser(uid);
  const seen=new Set([...(q.get('seen')||'').split(',').slice(0,300),...(user?.seen||[])]);
  let cats=(q.get('cats')||'').split(',').filter(c=>TOPICS[c]);if(!cats.length)cats=Object.keys(TOPICS);
  const jobs=[];
  if(mode==='following'){if(!user)throw new E('Log in to see creators you follow',401);
    for(const f of shuffle(user.follows).slice(0,4))jobs.push(f.source==='youtube'?(YT&&youtube({channel:f.cid,lang})):f.source==='archive'?archive({creator:f.cid}):commons({user:f.cid}))}
  else if(mode==='trending')jobs.push(YT&&youtube({popular:1,lang}),archive({sort:1}));
  else{const cat=pick(cats),t=pick(TOPICS[cat]);jobs.push(commons({q:t}),archive({q:t}),YT&&youtube({q:t,cat,lang}))}
  const errs=[],res=(await Promise.allSettled(jobs.filter(Boolean))).flatMap(r=>r.status==='fulfilled'?r.value:(errs.push(r.reason?.message),[]));
  if(!res.length&&errs.length)throw new E('Could not load videos: '+errs[0],502);
  const ids=new Set(),vids=shuffle(res).filter(v=>ID.test(v.id)&&!seen.has(v.id)&&!BAD.test(v.title)&&!ids.has(v.id)&&ids.add(v.id)).slice(0,10);
  const st=await statsFor(vids.map(v=>v.id));
  return{videos:vids.map(v=>decorate(v,st[v.id],user))}},
'GET /saved':async({uid})=>{const u=await needUser(uid),list=[...u.saves].reverse(),st=await statsFor(list.map(v=>v.id));return{videos:list.map(v=>decorate(v,st[v.id],u))}},

'POST /view':async({uid,body})=>{const id=vidId(body),u=await getUser(uid);let count=true;
  if(u){if(u.seen.includes(id))count=false;else{u.seen=[...u.seen.slice(-499),id];await putUser(u)}}
  if(count)await bump(id,d=>d.views++);return{ok:true}},
'POST /like':async({uid,body})=>{const u=await needUser(uid),id=vidId(body),on=!u.likes.includes(id);
  u.likes=on?[...u.likes,id]:u.likes.filter(x=>x!==id);await putUser(u);
  const d=await bump(id,d=>{d.likes=Math.max(0,d.likes+(on?1:-1))});return{on,count:d.likes}},
'POST /save':async({uid,body})=>{const u=await needUser(uid),id=vidId(body.video||{}),has=u.saves.some(s=>s.id===id);
  if(has)u.saves=u.saves.filter(s=>s.id!==id);else{if(u.saves.length>=200)throw new E('Favorites are full (200)');u.saves.push(cleanVideo(body.video))}
  await putUser(u);return{on:!has}},
'POST /follow':async({uid,body})=>{const u=await needUser(uid),f={name:String(body.name||'').slice(0,100),source:String(body.source||''),cid:String(body.cid||'').slice(0,100)};
  if(!f.cid||!['youtube','commons','archive'].includes(f.source))throw new E('Invalid creator');
  const has=u.follows.some(x=>x.source===f.source&&x.cid===f.cid);
  u.follows=has?u.follows.filter(x=>!(x.source===f.source&&x.cid===f.cid)):[...u.follows.slice(-199),f];await putUser(u);return{on:!has}},
'POST /report':async({uid,body})=>{const u=await needUser(uid),id=vidId(body);await S('reports').setJSON(`${h(id)}/${u.id}`,{id,t:Date.now()});await bump(id,d=>{d.reports=(d.reports||0)+1});return{ok:true}},

'GET /comments':async({url,uid})=>{const id=vidId({id:url.searchParams.get('id')}),u=await getUser(uid),adult=u?.prefs.maturity==='adult';
  const d=(await S('comments').get('c/'+h(id),{type:'json'}))||[];
  return{comments:d.filter(c=>!c.hidden).map(c=>({id:c.id,parent_id:c.parent,name:c.name,created:c.created,text:adult?c.text:c.text.replace(MILD,'***')}))}},
'POST /comments':async({uid,body,ip})=>{await limit('cmt',ip,8,60);const u=await needUser(uid),id=vidId(body);
  const text=String(body.text||'').trim().replace(/\s+/g,' ');
  if(!text||text.length>300)throw new E('Comment must be 1–300 characters');if(STRONG.test(text))throw new E('Comment blocked by moderation',422);
  const C=S('comments'),k='c/'+h(id),d=(await C.get(k,{type:'json'}))||[],parent=body.parent?+body.parent:null;
  if(parent&&!d.some(c=>c.id===parent))throw new E('Parent comment not found');
  d.push({id:Math.max(0,...d.map(c=>c.id))+1,parent,uid:u.id,name:u.display_name,text,created:Math.floor(Date.now()/1e3),reports:[],hidden:false});
  await C.setJSON(k,d.slice(-500));u.ncomments=(u.ncomments||0)+1;await putUser(u);
  await bump(id,x=>{x.comments=d.filter(c=>!c.hidden).length});return{ok:true}},
'POST /comments/report':async({uid,body})=>{const u=await needUser(uid),id=vidId(body),C=S('comments'),k='c/'+h(id),d=(await C.get(k,{type:'json'}))||[],c=d.find(x=>x.id===+body.cid);
  if(!c)throw new E('Not found',404);if(!c.reports.includes(u.id))c.reports.push(u.id);if(c.reports.length>=3)c.hidden=true;await C.setJSON(k,d);return{ok:true}},
};

export default async(req,ctx)=>{
  try{
    const url=new URL(req.url),fn=R[req.method+' '+url.pathname.replace(/^\/api/,'')];
    if(!fn)throw new E('Not found',404);
    let body={};
    if(req.method==='POST'||req.method==='PUT'){const t=await req.text();if(t.length>20000)throw new E('Request too large',413);try{body=JSON.parse(t||'{}')}catch{throw new E('Bad JSON')}}
    return j(await fn({url,body,uid:verify((req.headers.get('authorization')||'').slice(7)),ip:ctx.ip||'unknown'}));
  }catch(e){if(e instanceof E)return j({error:e.message},e.c);console.error(e);return j({error:'Server error'},500)}
};
export const config={path:'/api/*'};
